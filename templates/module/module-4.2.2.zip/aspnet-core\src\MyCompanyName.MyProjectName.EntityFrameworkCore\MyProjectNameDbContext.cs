﻿using Microsoft.EntityFrameworkCore;
using MyCompanyName.MyProjectName.Domain;
using MyCompanyName.MyProjectName.Domain.Entities;
using Volo.Abp.Data;
using Volo.Abp.EntityFrameworkCore;

namespace MyCompanyName.MyProjectName.EntityFrameworkCore
{
    [ConnectionStringName(MyProjectNameDbProperties.ConnectionStringName)]
    public class MyProjectNameDbContext : AbpDbContext<MyProjectNameDbContext>, IMyProjectNameDbContext
    {
        // Add DbSet for each Aggregate Root
        public DbSet<Order> Orders { get; set; }  // Todo: get or set ?

        public MyProjectNameDbContext(DbContextOptions<MyProjectNameDbContext> options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.ConfigureMyProjectName();
        }
    }
}