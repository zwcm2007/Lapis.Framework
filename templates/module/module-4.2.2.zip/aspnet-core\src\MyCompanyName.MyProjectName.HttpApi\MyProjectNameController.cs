﻿using Volo.Abp.AspNetCore.Mvc;

namespace MyCompanyName.MyProjectName.HttpApi
{
    public abstract class MyProjectNameController : AbpController
    {
        protected MyProjectNameController()
        {
        }
    }
}