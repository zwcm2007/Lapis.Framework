﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using System.IO;

namespace MyCompanyName.MyProjectName.EntityFrameworkCore
{
    public class MyProjectNameHttpApiHostMigrationsDbContextFactory : IDesignTimeDbContextFactory<MyProjectNameHttpApiHostMigrationsDbContext>
    {
        public MyProjectNameHttpApiHostMigrationsDbContext CreateDbContext(string[] args)
        {
            var configuration = BuildConfiguration();

            var connStr = configuration.GetConnectionString("MyProjectName");
            var builder = new DbContextOptionsBuilder<MyProjectNameHttpApiHostMigrationsDbContext>()
                .UseMySql(connStr, ServerVersion.AutoDetect(connStr));

            return new MyProjectNameHttpApiHostMigrationsDbContext(builder.Options);
        }

        private static IConfigurationRoot BuildConfiguration()
        {
            var builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json", optional: false);

            return builder.Build();
        }
    }
}