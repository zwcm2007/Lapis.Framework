﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Reflection;
using Volo.Abp;

namespace MyCompanyName.MyProjectName.EntityFrameworkCore
{
    public static class MyProjectNameDbContextModelCreatingExtensions
    {
        public static void ConfigureMyProjectName(
            this ModelBuilder builder,
            Action<MyProjectNameModelBuilderConfigurationOptions> optionsAction = null)
        {
            Check.NotNull(builder, nameof(builder));

            builder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());

            //var options = new MyProjectNameModelBuilderConfigurationOptions(
            //    MyProjectNameDbProperties.DbTablePrefix,
            //    MyProjectNameDbProperties.DbSchema
            //);

            //optionsAction?.Invoke(options);
        }
    }
}