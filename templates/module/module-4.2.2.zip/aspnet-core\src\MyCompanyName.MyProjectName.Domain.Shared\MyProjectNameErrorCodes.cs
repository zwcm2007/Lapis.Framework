﻿namespace MyCompanyName.MyProjectName.Domain
{
    public static class MyProjectNameErrorCodes
    {
        //Add your business exception error codes here...
    }
}
