﻿namespace MyCompanyName.MyProjectName.Application.Contracts
{
    public class OrderDto
    {
        public int Value { get; set; }
    }
}